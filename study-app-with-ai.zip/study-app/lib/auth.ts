// Simple localStorage-based auth context
export type User = {
  id: string;
  name: string;
  email: string;
  avatar: string;
  joinedAt: string;
};

export type Course = {
  id: string;
  name: string;
  progress: number;
  color: string;
  studyHours: number;
  lastStudied: string;
};

export type StudySession = {
  date: string;
  hours: number;
  course: string;
};

export type AppState = {
  user: User | null;
  courses: Course[];
  sessions: StudySession[];
  recentActivity: string[];
  chats: { id: string; title: string; messages: { role: string; content: string }[] }[];
};

export function getState(): AppState {
  if (typeof window === "undefined") return defaultState();
  try {
    const raw = localStorage.getItem("studyai_state");
    if (!raw) return defaultState();
    return JSON.parse(raw);
  } catch {
    return defaultState();
  }
}

export function setState(state: AppState) {
  if (typeof window === "undefined") return;
  localStorage.setItem("studyai_state", JSON.stringify(state));
}

export function defaultState(): AppState {
  return {
    user: null,
    courses: [
      { id: "1", name: "Mathematics", progress: 72, color: "#38bdf8", studyHours: 24, lastStudied: "Today" },
      { id: "2", name: "Physics", progress: 58, color: "#a78bfa", studyHours: 18, lastStudied: "Yesterday" },
      { id: "3", name: "Programming", progress: 91, color: "#34d399", studyHours: 42, lastStudied: "Today" },
      { id: "4", name: "Biology", progress: 45, color: "#f472b6", studyHours: 12, lastStudied: "3 days ago" },
      { id: "5", name: "Chemistry", progress: 33, color: "#fb923c", studyHours: 8, lastStudied: "1 week ago" },
      { id: "6", name: "Statistics", progress: 67, color: "#facc15", studyHours: 15, lastStudied: "2 days ago" },
    ],
    sessions: [
      { date: "Mon", hours: 2, course: "Mathematics" },
      { date: "Tue", hours: 4, course: "Programming" },
      { date: "Wed", hours: 3, course: "Physics" },
      { date: "Thu", hours: 5, course: "Mathematics" },
      { date: "Fri", hours: 6, course: "Programming" },
      { date: "Sat", hours: 4, course: "Biology" },
      { date: "Sun", hours: 7, course: "Statistics" },
    ],
    recentActivity: [
      "Completed Physics Quiz",
      "Studied Mathematics for 2h",
      "Used AI Assistant",
      "Finished Biology Notes",
    ],
    chats: [],
  };
}

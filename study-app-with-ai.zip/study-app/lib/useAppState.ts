"use client";
import { useState, useEffect, useCallback } from "react";
import { getState, setState, AppState, defaultState } from "./auth";

export function useAppState() {
  const [state, setStateLocal] = useState<AppState>(defaultState());
  const [loaded, setLoaded] = useState(false);

  useEffect(() => {
    setStateLocal(getState());
    setLoaded(true);
  }, []);

  const update = useCallback((partial: Partial<AppState>) => {
    setStateLocal(prev => {
      const next = { ...prev, ...partial };
      setState(next);
      return next;
    });
  }, []);

  return { state, update, loaded };
}

"use client";
import { useState } from "react";
import { useRouter } from "next/navigation";
import Link from "next/link";
import { getState, setState } from "@/lib/auth";

export default function SignupPage() {
  const router = useRouter();
  const [name, setName] = useState("");
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [error, setError] = useState("");
  const [loading, setLoading] = useState(false);

  const handleSignup = async (e: React.FormEvent) => {
    e.preventDefault();
    setError("");
    if (!name || !email || !password) { setError("Please fill in all fields."); return; }
    if (password.length < 6) { setError("Password must be at least 6 characters."); return; }
    setLoading(true);
    await new Promise(r => setTimeout(r, 700));
    const state = getState();
    setState({
      ...state,
      user: {
        id: Date.now().toString(),
        name: name.trim(),
        email,
        avatar: name[0].toUpperCase(),
        joinedAt: new Date().toISOString(),
      },
      recentActivity: [`${name} joined StudyAI`, ...state.recentActivity.slice(0, 3)],
    });
    setLoading(false);
    router.push("/dashboard");
  };

  return (
    <main style={{
      minHeight: "100vh",
      background: "linear-gradient(135deg, #0a0f1a 0%, #111827 50%, #0f1f35 100%)",
      display: "flex", justifyContent: "center", alignItems: "center", padding: "20px",
    }}>
      <div style={{
        width: "100%", maxWidth: "400px",
        background: "#111827", padding: "40px",
        borderRadius: "24px", border: "1px solid #1e293b",
      }}>
        <Link href="/" style={{ textDecoration: "none" }}>
          <h1 style={{ color: "#38bdf8", fontSize: "22px", fontWeight: "800", marginBottom: "30px" }}>
            Study<span style={{ color: "white" }}>AI</span>
          </h1>
        </Link>
        <h2 style={{ color: "white", fontSize: "28px", fontWeight: "700", marginBottom: "8px" }}>Create account</h2>
        <p style={{ color: "#64748b", marginBottom: "28px", fontSize: "14px" }}>Start your AI-powered learning journey</p>

        <form onSubmit={handleSignup} style={{ display: "flex", flexDirection: "column", gap: "16px" }}>
          <input type="text" placeholder="Full name" value={name} onChange={e => setName(e.target.value)} style={inputStyle} />
          <input type="email" placeholder="Email address" value={email} onChange={e => setEmail(e.target.value)} style={inputStyle} />
          <input type="password" placeholder="Password (6+ chars)" value={password} onChange={e => setPassword(e.target.value)} style={inputStyle} />
          {error && <p style={{ color: "#f87171", fontSize: "13px" }}>{error}</p>}
          <button type="submit" disabled={loading} style={{
            padding: "14px", borderRadius: "12px", border: "none",
            background: loading ? "#1e3a4a" : "#38bdf8", color: loading ? "#64748b" : "#0f172a",
            fontWeight: "700", fontSize: "15px", cursor: loading ? "not-allowed" : "pointer",
          }}>
            {loading ? "Creating account..." : "Create Account"}
          </button>
        </form>

        <p style={{ marginTop: "24px", textAlign: "center", color: "#64748b", fontSize: "14px" }}>
          Already have an account?{" "}
          <Link href="/login" style={{ color: "#38bdf8", textDecoration: "none", fontWeight: "600" }}>Sign in</Link>
        </p>
      </div>
    </main>
  );
}

const inputStyle: React.CSSProperties = {
  padding: "14px", borderRadius: "12px", border: "1px solid #1e293b",
  background: "#0a0f1a", color: "white", fontSize: "15px", outline: "none",
  width: "100%",
};

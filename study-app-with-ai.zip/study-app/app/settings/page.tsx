import Sidebar from "@/components/layout/Sidebar";

export default function SettingsPage() {
  return (
    <main
      style={{
        minHeight: "100vh",
        display: "flex",
        background:
          "linear-gradient(to bottom right, #0f172a, #111827, #1e293b)",
      }}
    >
      <Sidebar />

      <section
        style={{
          flex: 1,
          padding: "40px",
        }}
      >
        <h1
          style={{
            color: "white",
            fontSize: "40px",
            marginBottom: "30px",
          }}
        >
          Settings
        </h1>

        <div
          style={{
            background: "#111827",
            border: "1px solid #1e293b",
            borderRadius: "24px",
            padding: "30px",
            maxWidth: "600px",
          }}
        >
          <div
            style={{
              marginBottom: "25px",
            }}
          >
            <label
              style={{
                color: "white",
                display: "block",
                marginBottom: "10px",
              }}
            >
              Username
            </label>

            <input
              type="text"
              defaultValue="Bless"
              style={{
                width: "100%",
                padding: "14px",
                borderRadius: "14px",
                border: "1px solid #334155",
                background: "#0f172a",
                color: "white",
                outline: "none",
              }}
            />
          </div>

          <div
            style={{
              marginBottom: "25px",
            }}
          >
            <label
              style={{
                color: "white",
                display: "block",
                marginBottom: "10px",
              }}
            >
              Email
            </label>

            <input
              type="email"
              defaultValue="bless@example.com"
              style={{
                width: "100%",
                padding: "14px",
                borderRadius: "14px",
                border: "1px solid #334155",
                background: "#0f172a",
                color: "white",
                outline: "none",
              }}
            />
          </div>

          <button
            style={{
              padding: "14px 22px",
              border: "none",
              borderRadius: "14px",
              background: "#38bdf8",
              color: "#0f172a",
              fontWeight: "bold",
              cursor: "pointer",
            }}
          >
            Save Changes
          </button>
        </div>
      </section>
    </main>
  );
}
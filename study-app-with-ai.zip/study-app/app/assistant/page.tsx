"use client";
import { useState, useEffect, useRef } from "react";
import { useRouter } from "next/navigation";
import { useAppState } from "@/lib/useAppState";

type Message = { role: "user" | "assistant"; content: string };
type Chat = { id: string; title: string; messages: Message[] };

export default function AssistantPage() {
  const { state, update, loaded } = useAppState();
  const router = useRouter();
  const [chats, setChats] = useState<Chat[]>([]);
  const [activeChatId, setActiveChatId] = useState<string | null>(null);
  const [input, setInput] = useState("");
  const [loading, setLoading] = useState(false);
  const messagesEndRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    if (loaded && !state.user) router.push("/login");
    if (loaded) setChats(state.chats || []);
  }, [loaded, state.user]);

  useEffect(() => {
    messagesEndRef.current?.scrollIntoView({ behavior: "smooth" });
  }, [chats, activeChatId]);

  const activeChat = chats.find(c => c.id === activeChatId);

  const newChat = () => {
    const id = Date.now().toString();
    const chat: Chat = { id, title: "New Chat", messages: [] };
    const updated = [chat, ...chats];
    setChats(updated);
    setActiveChatId(id);
    update({ chats: updated });
  };

  const sendMessage = async () => {
    if (!input.trim() || loading) return;
    const userMsg: Message = { role: "user", content: input.trim() };
    setInput("");

    let currentChatId = activeChatId;
    let currentChats = chats;

    // Create a new chat if none active
    if (!currentChatId) {
      const id = Date.now().toString();
      const title = input.trim().slice(0, 40);
      const chat: Chat = { id, title, messages: [userMsg] };
      currentChats = [chat, ...chats];
      setChats(currentChats);
      setActiveChatId(id);
      currentChatId = id;
    } else {
      currentChats = currentChats.map(c => {
        if (c.id !== currentChatId) return c;
        const msgs = [...c.messages, userMsg];
        return {
          ...c,
          messages: msgs,
          title: c.title === "New Chat" ? input.trim().slice(0, 40) : c.title,
        };
      });
      setChats(currentChats);
    }

    update({ chats: currentChats });
    setLoading(true);

    try {
      const chat = currentChats.find(c => c.id === currentChatId)!;
      const systemPrompt = `You are StudyAI, an expert study assistant helping students learn effectively. The student's name is ${state.user?.name || "there"}. They are enrolled in: ${state.courses.map(c => c.name).join(", ")}. Be encouraging, clear, and educational. Use examples and analogies. Keep responses concise but thorough. Format with markdown when helpful (bold, lists, code blocks).`;

      const response = await fetch("/api/chat", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          systemPrompt,
          messages: chat.messages.map(m => ({ role: m.role, content: m.content })),
        }),
      });

      const data = await response.json();
      const aiContent = data.content || data.error || "Sorry, I couldn't generate a response.";
      const aiMsg: Message = { role: "assistant", content: aiContent };

      const withReply = currentChats.map(c =>
        c.id === currentChatId ? { ...c, messages: [...c.messages, aiMsg] } : c
      );
      setChats(withReply);
      update({
        chats: withReply,
        recentActivity: [`Asked AI: "${userMsg.content.slice(0, 40)}..."`, ...state.recentActivity.slice(0, 5)],
      });
    } catch {
      const errMsg: Message = { role: "assistant", content: "Something went wrong connecting to the AI. Please try again." };
      const withErr = currentChats.map(c =>
        c.id === currentChatId ? { ...c, messages: [...c.messages, errMsg] } : c
      );
      setChats(withErr);
      update({ chats: withErr });
    }
    setLoading(false);
  };

  const handleKey = (e: React.KeyboardEvent) => {
    if (e.key === "Enter" && !e.shiftKey) { e.preventDefault(); sendMessage(); }
  };

  if (!loaded || !state.user) return null;

  return (
    <main style={{ minHeight: "100vh", display: "flex", background: "linear-gradient(135deg, #0a0f1a, #111827)" }}>
      {/* SIDEBAR */}
      <aside style={{ width: "260px", background: "#0a0f1a", borderRight: "1px solid #1e293b", padding: "20px", display: "flex", flexDirection: "column", gap: "12px" }}>
        <button onClick={newChat} style={{
          width: "100%", padding: "12px", borderRadius: "12px", border: "1px solid rgba(56,189,248,0.3)",
          background: "rgba(56,189,248,0.08)", color: "#38bdf8", fontWeight: "700", cursor: "pointer", fontSize: "14px",
        }}>
          + New Chat
        </button>
        <div style={{ flex: 1, overflowY: "auto", display: "flex", flexDirection: "column", gap: "6px" }}>
          {chats.map(chat => (
            <div key={chat.id} onClick={() => setActiveChatId(chat.id)} style={{
              padding: "12px 14px", borderRadius: "10px", cursor: "pointer", fontSize: "13px",
              background: activeChatId === chat.id ? "rgba(56,189,248,0.1)" : "transparent",
              border: activeChatId === chat.id ? "1px solid rgba(56,189,248,0.2)" : "1px solid transparent",
              color: activeChatId === chat.id ? "#e2e8f0" : "#64748b",
              whiteSpace: "nowrap", overflow: "hidden", textOverflow: "ellipsis",
            }}>
              {chat.title || "New Chat"}
            </div>
          ))}
          {chats.length === 0 && (
            <p style={{ color: "#475569", fontSize: "13px", textAlign: "center", marginTop: "20px" }}>No chats yet. Start one!</p>
          )}
        </div>
        <button onClick={() => router.push("/dashboard")} style={{
          padding: "10px", background: "transparent", border: "1px solid #1e293b",
          borderRadius: "10px", color: "#64748b", fontSize: "13px", cursor: "pointer",
        }}>
          ← Dashboard
        </button>
      </aside>

      {/* MAIN CHAT */}
      <section style={{ flex: 1, display: "flex", flexDirection: "column" }}>
        <div style={{
          padding: "18px 24px", borderBottom: "1px solid #1e293b",
          background: "rgba(10,15,26,0.8)", backdropFilter: "blur(12px)",
        }}>
          <h1 style={{ color: "white", fontSize: "18px", fontWeight: "700" }}>✦ AI Study Assistant</h1>
          <p style={{ color: "#64748b", fontSize: "13px" }}>Ask questions, get explanations, study smarter.</p>
        </div>

        <div style={{ flex: 1, overflowY: "auto", padding: "24px", display: "flex", flexDirection: "column", gap: "16px" }}>
          {!activeChat || activeChat.messages.length === 0 ? (
            <div style={{ display: "flex", flexDirection: "column", alignItems: "center", justifyContent: "center", flex: 1, gap: "16px", paddingTop: "60px" }}>
              <div style={{ fontSize: "48px" }}>✦</div>
              <h2 style={{ color: "white", fontSize: "20px", fontWeight: "700" }}>How can I help you study?</h2>
              <p style={{ color: "#64748b", maxWidth: "400px", textAlign: "center", fontSize: "14px" }}>
                Ask me to explain concepts, quiz you, summarize notes, solve problems, or help with any subject.
              </p>
              <div style={{ display: "flex", flexWrap: "wrap", gap: "8px", justifyContent: "center", maxWidth: "500px" }}>
                {[
                  "Explain Newton's Laws of Motion",
                  "Quiz me on Mathematics",
                  "Help me understand recursion in Programming",
                  "Summarize photosynthesis",
                ].map(prompt => (
                  <button key={prompt} onClick={() => setInput(prompt)} style={{
                    padding: "8px 14px", borderRadius: "20px", border: "1px solid #1e293b",
                    background: "#111827", color: "#94a3b8", fontSize: "13px", cursor: "pointer",
                  }}>
                    {prompt}
                  </button>
                ))}
              </div>
            </div>
          ) : (
            activeChat.messages.map((msg, i) => (
              <div key={i} style={{ display: "flex", justifyContent: msg.role === "user" ? "flex-end" : "flex-start" }}>
                {msg.role === "assistant" && (
                  <div style={{
                    width: "28px", height: "28px", borderRadius: "50%", background: "rgba(56,189,248,0.15)",
                    border: "1px solid rgba(56,189,248,0.3)", display: "flex", alignItems: "center",
                    justifyContent: "center", fontSize: "12px", flexShrink: 0, marginRight: "10px", marginTop: "2px",
                  }}>✦</div>
                )}
                <div style={{
                  maxWidth: "70%", padding: "14px 18px", borderRadius: "18px", lineHeight: "1.6", fontSize: "14px",
                  background: msg.role === "user" ? "#38bdf8" : "#111827",
                  color: msg.role === "user" ? "#0f172a" : "#e2e8f0",
                  border: msg.role === "assistant" ? "1px solid #1e293b" : "none",
                  borderRadius: msg.role === "user" ? "18px 18px 4px 18px" : "18px 18px 18px 4px",
                  whiteSpace: "pre-wrap",
                }}>
                  {msg.content}
                </div>
              </div>
            ))
          )}
          {loading && (
            <div style={{ display: "flex", alignItems: "center", gap: "10px" }}>
              <div style={{ width: "28px", height: "28px", borderRadius: "50%", background: "rgba(56,189,248,0.15)", border: "1px solid rgba(56,189,248,0.3)", display: "flex", alignItems: "center", justifyContent: "center", fontSize: "12px" }}>✦</div>
              <div style={{ background: "#111827", border: "1px solid #1e293b", padding: "14px 18px", borderRadius: "18px 18px 18px 4px" }}>
                <span style={{ color: "#64748b", fontSize: "14px" }}>Thinking...</span>
              </div>
            </div>
          )}
          <div ref={messagesEndRef} />
        </div>

        <div style={{ padding: "16px 24px", borderTop: "1px solid #1e293b", background: "rgba(10,15,26,0.8)" }}>
          <div style={{ display: "flex", gap: "12px", alignItems: "flex-end" }}>
            <textarea
              value={input}
              onChange={e => setInput(e.target.value)}
              onKeyDown={handleKey}
              placeholder="Ask anything... (Enter to send, Shift+Enter for new line)"
              rows={1}
              style={{
                flex: 1, padding: "14px 18px", borderRadius: "14px", border: "1px solid #1e293b",
                background: "#111827", color: "white", fontSize: "14px", outline: "none",
                resize: "none", fontFamily: "inherit", lineHeight: "1.5",
              }}
            />
            <button
              onClick={sendMessage}
              disabled={loading || !input.trim()}
              style={{
                padding: "14px 20px", borderRadius: "14px", border: "none",
                background: loading || !input.trim() ? "#1e293b" : "#38bdf8",
                color: loading || !input.trim() ? "#475569" : "#0f172a",
                fontWeight: "700", fontSize: "14px", cursor: loading || !input.trim() ? "not-allowed" : "pointer",
                whiteSpace: "nowrap",
              }}
            >
              {loading ? "..." : "Send ↑"}
            </button>
          </div>
        </div>
      </section>
    </main>
  );
}

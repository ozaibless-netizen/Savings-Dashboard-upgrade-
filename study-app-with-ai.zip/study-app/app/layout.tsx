import "./globals.css";

export const metadata = {
  title: "Study App",
  description: "Modern AI-powered study platform",
};

export default function RootLayout({
  children,
}: {
  children: React.ReactNode;
}) {
  return (
    <html lang="en">
      <body>{children}</body>
    </html>
  );
}
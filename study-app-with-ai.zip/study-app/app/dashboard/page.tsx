"use client";
import { useEffect } from "react";
import { useRouter } from "next/navigation";
import PageLayout from "@/components/layout/PageLayout";
import { useAppState } from "@/lib/useAppState";

export default function DashboardPage() {
  const { state, loaded } = useAppState();
  const router = useRouter();

  useEffect(() => {
    if (loaded && !state.user) router.push("/login");
  }, [loaded, state.user, router]);

  if (!loaded || !state.user) return null;

  const totalHours = state.courses.reduce((a, c) => a + c.studyHours, 0);
  const avgProgress = Math.round(state.courses.reduce((a, c) => a + c.progress, 0) / state.courses.length);

  return (
    <PageLayout>
      <div style={{ marginBottom: "32px" }}>
        <h1 style={{ color: "white", fontSize: "32px", fontWeight: "800", marginBottom: "6px" }}>
          Good {getGreeting()}, {state.user.name} 👋
        </h1>
        <p style={{ color: "#64748b", fontSize: "15px" }}>Here's your learning overview.</p>
      </div>

      {/* STATS */}
      <div style={{ display: "grid", gridTemplateColumns: "repeat(auto-fit, minmax(200px, 1fr))", gap: "16px", marginBottom: "32px" }}>
        {[
          { label: "Courses", value: state.courses.length.toString(), icon: "📚", color: "#38bdf8" },
          { label: "Study Hours", value: `${totalHours}h`, icon: "⏱", color: "#a78bfa" },
          { label: "Avg Progress", value: `${avgProgress}%`, icon: "📈", color: "#34d399" },
          { label: "AI Chats", value: state.chats.length.toString(), icon: "✦", color: "#f472b6" },
        ].map(s => (
          <div key={s.label} style={{
            background: "#111827", border: "1px solid #1e293b",
            borderRadius: "16px", padding: "22px",
          }}>
            <div style={{ display: "flex", justifyContent: "space-between", alignItems: "flex-start" }}>
              <div>
                <p style={{ color: "#64748b", fontSize: "13px", marginBottom: "8px" }}>{s.label}</p>
                <h3 style={{ color: "white", fontSize: "28px", fontWeight: "700" }}>{s.value}</h3>
              </div>
              <span style={{ fontSize: "24px" }}>{s.icon}</span>
            </div>
          </div>
        ))}
      </div>

      <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr", gap: "16px" }}>
        {/* COURSES PROGRESS */}
        <div style={{ background: "#111827", border: "1px solid #1e293b", borderRadius: "16px", padding: "24px" }}>
          <h2 style={{ color: "white", fontSize: "16px", fontWeight: "700", marginBottom: "20px" }}>Course Progress</h2>
          {state.courses.slice(0, 4).map(c => (
            <div key={c.id} style={{ marginBottom: "16px" }}>
              <div style={{ display: "flex", justifyContent: "space-between", marginBottom: "6px" }}>
                <span style={{ color: "#cbd5e1", fontSize: "13px" }}>{c.name}</span>
                <span style={{ color: c.color, fontSize: "13px", fontWeight: "600" }}>{c.progress}%</span>
              </div>
              <div style={{ width: "100%", height: "6px", background: "#0a0f1a", borderRadius: "999px" }}>
                <div style={{ width: `${c.progress}%`, height: "100%", background: c.color, borderRadius: "999px", transition: "width 0.8s ease" }} />
              </div>
            </div>
          ))}
        </div>

        {/* RECENT ACTIVITY */}
        <div style={{ background: "#111827", border: "1px solid #1e293b", borderRadius: "16px", padding: "24px" }}>
          <h2 style={{ color: "white", fontSize: "16px", fontWeight: "700", marginBottom: "20px" }}>Recent Activity</h2>
          {state.recentActivity.slice(0, 6).map((a, i) => (
            <div key={i} style={{
              padding: "10px 0", borderBottom: i < state.recentActivity.length - 1 ? "1px solid #1e293b" : "none",
              color: "#94a3b8", fontSize: "13px", display: "flex", alignItems: "center", gap: "8px",
            }}>
              <span style={{ color: "#38bdf8", fontSize: "8px" }}>●</span>
              {a}
            </div>
          ))}
        </div>
      </div>
    </PageLayout>
  );
}

function getGreeting() {
  const h = new Date().getHours();
  if (h < 12) return "morning";
  if (h < 17) return "afternoon";
  return "evening";
}

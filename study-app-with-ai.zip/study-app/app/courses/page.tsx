"use client";
import { useEffect } from "react";
import { useRouter } from "next/navigation";
import PageLayout from "@/components/layout/PageLayout";
import { useAppState } from "@/lib/useAppState";

export default function CoursesPage() {
  const { state, update, loaded } = useAppState();
  const router = useRouter();

  useEffect(() => {
    if (loaded && !state.user) router.push("/login");
  }, [loaded, state.user, router]);

  if (!loaded || !state.user) return null;

  const studyCourse = (courseId: string) => {
    const now = new Date();
    const updated = state.courses.map(c => {
      if (c.id !== courseId) return c;
      const newProgress = Math.min(100, c.progress + Math.floor(Math.random() * 5) + 1);
      return { ...c, progress: newProgress, studyHours: c.studyHours + 1, lastStudied: "Just now" };
    });
    const course = state.courses.find(c => c.id === courseId);
    const newActivity = [`Opened ${course?.name}`, ...state.recentActivity.slice(0, 5)];
    update({ courses: updated, recentActivity: newActivity });
  };

  return (
    <PageLayout>
      <div style={{ marginBottom: "28px" }}>
        <h1 style={{ color: "white", fontSize: "32px", fontWeight: "800", marginBottom: "6px" }}>Courses</h1>
        <p style={{ color: "#64748b" }}>Continue learning and track your enrolled subjects.</p>
      </div>

      <div style={{ display: "grid", gridTemplateColumns: "repeat(auto-fill, minmax(280px, 1fr))", gap: "16px" }}>
        {state.courses.map(course => (
          <div key={course.id} style={{
            background: "#111827", border: "1px solid #1e293b",
            borderRadius: "20px", padding: "24px",
            transition: "border-color 0.2s",
          }}>
            <div style={{
              width: "44px", height: "44px", borderRadius: "12px",
              background: `${course.color}18`, border: `1px solid ${course.color}40`,
              display: "flex", alignItems: "center", justifyContent: "center",
              marginBottom: "16px", fontSize: "20px",
            }}>
              {courseIcon(course.name)}
            </div>

            <h2 style={{ color: "white", fontSize: "17px", fontWeight: "700", marginBottom: "6px" }}>{course.name}</h2>
            <p style={{ color: "#64748b", fontSize: "13px", marginBottom: "16px" }}>
              {course.studyHours}h studied · Last: {course.lastStudied}
            </p>

            <div style={{ marginBottom: "16px" }}>
              <div style={{ display: "flex", justifyContent: "space-between", marginBottom: "6px" }}>
                <span style={{ color: "#94a3b8", fontSize: "12px" }}>Progress</span>
                <span style={{ color: course.color, fontSize: "12px", fontWeight: "600" }}>{course.progress}%</span>
              </div>
              <div style={{ width: "100%", height: "6px", background: "#0a0f1a", borderRadius: "999px" }}>
                <div style={{ width: `${course.progress}%`, height: "100%", background: course.color, borderRadius: "999px" }} />
              </div>
            </div>

            <button
              onClick={() => studyCourse(course.id)}
              style={{
                width: "100%", padding: "11px", borderRadius: "12px", border: "none",
                background: course.color, color: "#0f172a", fontWeight: "700",
                fontSize: "14px", cursor: "pointer",
              }}
            >
              Study Now
            </button>
          </div>
        ))}
      </div>
    </PageLayout>
  );
}

function courseIcon(name: string) {
  const icons: Record<string, string> = {
    Mathematics: "∑", Physics: "⚛", Programming: "{ }", Biology: "🧬",
    Chemistry: "⚗", Statistics: "📊",
  };
  return icons[name] || "📖";
}

import Navbar from "@/components/layout/Navbar";
import Button from "@/components/ui/Button";

export default function HomePage() {
  return (
    <main
      style={{
        minHeight: "100vh",
        background:
          "linear-gradient(to bottom right, #0f172a, #111827, #1e293b)",
        padding: "40px",
      }}
    >
      <Navbar />

      <section
        style={{
          display: "flex",
          flexDirection: "column",
          alignItems: "center",
          textAlign: "center",
          marginTop: "100px",
        }}
      >
        <h2
          style={{
            fontSize: "56px",
            maxWidth: "800px",
            lineHeight: "1.2",
            marginBottom: "25px",
            color: "white",
          }}
        >
          Learn Faster With AI-Powered Education
        </h2>

        <p
          style={{
            maxWidth: "700px",
            color: "#94a3b8",
            fontSize: "18px",
            lineHeight: "1.7",
            marginBottom: "40px",
          }}
        >
          Organize your courses, study smarter, track progress,
          and improve productivity with your intelligent study platform.
        </p>

        <div
          style={{
            display: "flex",
            gap: "20px",
          }}
        >
          <Button text="Get Started" />
          <Button text="Explore Features" primary={false} />
        </div>
      </section>
    </main>
  );
}
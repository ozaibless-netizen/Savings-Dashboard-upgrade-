import Sidebar from "@/components/layout/Sidebar";

export default function ProfilePage() {
  return (
    <main
      style={{
        minHeight: "100vh",
        display: "flex",
        background:
          "linear-gradient(to bottom right, #0f172a, #111827, #1e293b)",
      }}
    >
      <Sidebar />

      <section
        style={{
          flex: 1,
          padding: "40px",
        }}
      >
        <h1
          style={{
            color: "white",
            fontSize: "40px",
            marginBottom: "30px",
          }}
        >
          Profile
        </h1>

        <div
          style={{
            background: "#111827",
            border: "1px solid #1e293b",
            borderRadius: "24px",
            padding: "40px",
            maxWidth: "500px",
          }}
        >
          <div
            style={{
              width: "100px",
              height: "100px",
              borderRadius: "50%",
              background: "#38bdf8",
              marginBottom: "20px",
            }}
          />

          <h2
            style={{
              color: "white",
              marginBottom: "10px",
            }}
          >
            Bless
          </h2>

          <p
            style={{
              color: "#94a3b8",
              marginBottom: "30px",
            }}
          >
            Student • AI Learning Enthusiast
          </p>

          <button
            style={{
              padding: "14px 20px",
              border: "none",
              borderRadius: "14px",
              background: "#38bdf8",
              color: "#0f172a",
              fontWeight: "bold",
              cursor: "pointer",
            }}
          >
            Edit Profile
          </button>
        </div>
      </section>
    </main>
  );
}
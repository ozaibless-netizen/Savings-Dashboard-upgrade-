import PageLayout from "@/components/layout/PageLayout";

const weeklyData = [
  { day: "Mon", hours: 2 },
  { day: "Tue", hours: 4 },
  { day: "Wed", hours: 3 },
  { day: "Thu", hours: 5 },
  { day: "Fri", hours: 6 },
  { day: "Sat", hours: 4 },
  { day: "Sun", hours: 7 },
];

export default function AnalyticsPage() {
  return (
    <PageLayout>
      {/* HEADER */}
      <div
        style={{
          marginBottom: "40px",
        }}
      >
        <h1
          style={{
            color: "white",
            fontSize: "40px",
            marginBottom: "10px",
          }}
        >
          Analytics
        </h1>

        <p
          style={{
            color: "#94a3b8",
          }}
        >
          Track productivity, study time, and learning progress.
        </p>
      </div>

      {/* STATS */}
      <div
        style={{
          display: "grid",
          gridTemplateColumns:
            "repeat(auto-fit, minmax(220px, 1fr))",
          gap: "20px",
          marginBottom: "40px",
        }}
      >
        {[
          {
            title: "Study Hours",
            value: "31h",
          },
          {
            title: "Courses Completed",
            value: "8",
          },
          {
            title: "Assignments",
            value: "24",
          },
          {
            title: "Focus Score",
            value: "91%",
          },
        ].map((item) => (
          <div
            key={item.title}
            style={{
              background: "#111827",
              border: "1px solid #1e293b",
              borderRadius: "20px",
              padding: "25px",
            }}
          >
            <p
              style={{
                color: "#94a3b8",
                marginBottom: "12px",
              }}
            >
              {item.title}
            </p>

            <h2
              style={{
                color: "white",
                fontSize: "34px",
              }}
            >
              {item.value}
            </h2>
          </div>
        ))}
      </div>

      {/* CHART */}
      <div
        style={{
          background: "#111827",
          border: "1px solid #1e293b",
          borderRadius: "24px",
          padding: "30px",
          marginBottom: "40px",
        }}
      >
        <h2
          style={{
            color: "white",
            marginBottom: "30px",
          }}
        >
          Weekly Study Activity
        </h2>

        <div
          style={{
            display: "flex",
            alignItems: "flex-end",
            gap: "20px",
            height: "300px",
          }}
        >
          {weeklyData.map((item) => (
            <div
              key={item.day}
              style={{
                flex: 1,
                display: "flex",
                flexDirection: "column",
                alignItems: "center",
                gap: "12px",
              }}
            >
              <div
                style={{
                  width: "100%",
                  height: `${item.hours * 35}px`,
                  background: "#38bdf8",
                  borderRadius: "14px 14px 0 0",
                }}
              />

              <p
                style={{
                  color: "#cbd5e1",
                }}
              >
                {item.day}
              </p>
            </div>
          ))}
        </div>
      </div>

      {/* SUBJECT PERFORMANCE */}
      <div
        style={{
          background: "#111827",
          border: "1px solid #1e293b",
          borderRadius: "24px",
          padding: "30px",
        }}
      >
        <h2
          style={{
            color: "white",
            marginBottom: "25px",
          }}
        >
          Subject Performance
        </h2>

        {[
          {
            subject: "Mathematics",
            score: 92,
          },
          {
            subject: "Physics",
            score: 81,
          },
          {
            subject: "Programming",
            score: 95,
          },
          {
            subject: "Biology",
            score: 76,
          },
        ].map((item) => (
          <div
            key={item.subject}
            style={{
              marginBottom: "22px",
            }}
          >
            <div
              style={{
                display: "flex",
                justifyContent: "space-between",
                marginBottom: "8px",
              }}
            >
              <span
                style={{
                  color: "white",
                }}
              >
                {item.subject}
              </span>

              <span
                style={{
                  color: "#38bdf8",
                }}
              >
                {item.score}%
              </span>
            </div>

            <div
              style={{
                width: "100%",
                height: "12px",
                background: "#0f172a",
                borderRadius: "999px",
              }}
            >
              <div
                style={{
                  width: `${item.score}%`,
                  height: "100%",
                  background: "#38bdf8",
                  borderRadius: "999px",
                }}
              />
            </div>
          </div>
        ))}
      </div>
    </PageLayout>
  );
}
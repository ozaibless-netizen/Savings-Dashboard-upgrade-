"use client";
import { useState } from "react";
import { useRouter } from "next/navigation";
import Link from "next/link";
import { getState, setState } from "@/lib/auth";

export default function LoginPage() {
  const router = useRouter();
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [error, setError] = useState("");
  const [loading, setLoading] = useState(false);

  const handleLogin = async (e: React.FormEvent) => {
    e.preventDefault();
    setError("");
    if (!email || !password) { setError("Please fill in all fields."); return; }
    setLoading(true);

    // Simulate auth — in a real app, hit your backend
    await new Promise(r => setTimeout(r, 600));
    const state = getState();
    const name = email.split("@")[0].replace(/[^a-zA-Z]/g, " ").trim() || "Student";
    setState({
      ...state,
      user: {
        id: Date.now().toString(),
        name: name.charAt(0).toUpperCase() + name.slice(1),
        email,
        avatar: name[0].toUpperCase(),
        joinedAt: new Date().toISOString(),
      },
    });
    setLoading(false);
    router.push("/dashboard");
  };

  return (
    <main style={{
      minHeight: "100vh",
      background: "linear-gradient(135deg, #0a0f1a 0%, #111827 50%, #0f1f35 100%)",
      display: "flex", justifyContent: "center", alignItems: "center", padding: "20px",
    }}>
      <div style={{
        width: "100%", maxWidth: "400px",
        background: "#111827", padding: "40px",
        borderRadius: "24px", border: "1px solid #1e293b",
      }}>
        <Link href="/" style={{ textDecoration: "none" }}>
          <h1 style={{ color: "#38bdf8", fontSize: "22px", fontWeight: "800", marginBottom: "30px" }}>
            Study<span style={{ color: "white" }}>AI</span>
          </h1>
        </Link>
        <h2 style={{ color: "white", fontSize: "28px", fontWeight: "700", marginBottom: "8px" }}>Welcome back</h2>
        <p style={{ color: "#64748b", marginBottom: "28px", fontSize: "14px" }}>Continue your learning journey</p>

        <form onSubmit={handleLogin} style={{ display: "flex", flexDirection: "column", gap: "16px" }}>
          <input
            type="email" placeholder="Email address" value={email}
            onChange={e => setEmail(e.target.value)}
            style={inputStyle}
          />
          <input
            type="password" placeholder="Password" value={password}
            onChange={e => setPassword(e.target.value)}
            style={inputStyle}
          />
          {error && <p style={{ color: "#f87171", fontSize: "13px" }}>{error}</p>}
          <button type="submit" disabled={loading} style={{
            padding: "14px", borderRadius: "12px", border: "none",
            background: loading ? "#1e3a4a" : "#38bdf8", color: loading ? "#64748b" : "#0f172a",
            fontWeight: "700", fontSize: "15px", cursor: loading ? "not-allowed" : "pointer",
          }}>
            {loading ? "Signing in..." : "Sign In"}
          </button>
        </form>

        <p style={{ marginTop: "24px", textAlign: "center", color: "#64748b", fontSize: "14px" }}>
          Don't have an account?{" "}
          <Link href="/signup" style={{ color: "#38bdf8", textDecoration: "none", fontWeight: "600" }}>Sign up</Link>
        </p>
      </div>
    </main>
  );
}

const inputStyle: React.CSSProperties = {
  padding: "14px", borderRadius: "12px", border: "1px solid #1e293b",
  background: "#0a0f1a", color: "white", fontSize: "15px", outline: "none",
  width: "100%",
};

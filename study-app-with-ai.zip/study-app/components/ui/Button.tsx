type ButtonProps = {
  text: string;
  primary?: boolean;
};

export default function Button({
  text,
  primary = true,
}: ButtonProps) {
  return (
    <button
      style={{
        padding: "14px 24px",
        borderRadius: "14px",
        border: primary ? "none" : "1px solid #334155",
        background: primary ? "#38bdf8" : "transparent",
        color: primary ? "#0f172a" : "white",
        fontWeight: "bold",
        fontSize: "15px",
        cursor: "pointer",
      }}
    >
      {text}
    </button>
  );
}
type CardProps = {
  title: string;
  value: string;
};

export default function Card({ title, value }: CardProps) {
  return (
    <div
      style={{
        background: "#111827",
        padding: "25px",
        borderRadius: "20px",
        border: "1px solid #1e293b",
      }}
    >
      <p
        style={{
          color: "#94a3b8",
          marginBottom: "12px",
        }}
      >
        {title}
      </p>

      <h3
        style={{
          fontSize: "32px",
          color: "white",
        }}
      >
        {value}
      </h3>
    </div>
  );
}
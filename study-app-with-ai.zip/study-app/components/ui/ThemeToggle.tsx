"use client";

import { useState } from "react";

export default function ThemeToggle() {
  const [darkMode, setDarkMode] = useState(true);

  return (
    <button
      onClick={() => setDarkMode(!darkMode)}
      style={{
        padding: "12px 18px",
        borderRadius: "14px",
        border: "1px solid #334155",
        background: darkMode ? "#111827" : "#e2e8f0",
        color: darkMode ? "white" : "#0f172a",
        cursor: "pointer",
        fontWeight: "bold",
      }}
    >
      {darkMode ? "🌙 Dark" : "☀️ Light"}
    </button>
  );
}
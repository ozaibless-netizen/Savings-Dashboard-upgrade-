export default function ChatSidebar() {
  return (
    <aside
      style={{
        width: "280px",
        background: "#111827",
        borderRight: "1px solid #1e293b",
        padding: "25px",
      }}
    >
      <button
        style={{
          width: "100%",
          padding: "14px",
          borderRadius: "14px",
          border: "none",
          background: "#38bdf8",
          color: "#0f172a",
          fontWeight: "bold",
          marginBottom: "30px",
          cursor: "pointer",
        }}
      >
        + New Chat
      </button>

      <div
        style={{
          display: "flex",
          flexDirection: "column",
          gap: "14px",
        }}
      >
        {[
          "Physics Revision",
          "Math Homework",
          "Programming Help",
          "Biology Notes",
        ].map((chat) => (
          <div
            key={chat}
            style={{
              padding: "14px",
              borderRadius: "14px",
              background: "#0f172a",
              border: "1px solid #1e293b",
              color: "#cbd5e1",
              cursor: "pointer",
            }}
          >
            {chat}
          </div>
        ))}
      </div>
    </aside>
  );
}
type MessageBubbleProps = {
  message: string;
  ai?: boolean;
};

export default function MessageBubble({
  message,
  ai = false,
}: MessageBubbleProps) {
  return (
    <div
      style={{
        display: "flex",
        justifyContent: ai ? "flex-start" : "flex-end",
        marginBottom: "18px",
      }}
    >
      <div
        style={{
          maxWidth: "75%",
          padding: "16px",
          borderRadius: "18px",
          background: ai ? "#111827" : "#38bdf8",
          color: ai ? "white" : "#0f172a",
          border: ai ? "1px solid #1e293b" : "none",
          lineHeight: "1.6",
        }}
      >
        {message}
      </div>
    </div>
  );
}
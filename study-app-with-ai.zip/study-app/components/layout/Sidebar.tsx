"use client";
import Link from "next/link";
import { usePathname, useRouter } from "next/navigation";
import { useAppState } from "@/lib/useAppState";

const menuItems = [
  { name: "Dashboard", path: "/dashboard", icon: "⊞" },
  { name: "Courses", path: "/courses", icon: "📚" },
  { name: "AI Assistant", path: "/assistant", icon: "✦" },
  { name: "Analytics", path: "/analytics", icon: "◈" },
  { name: "Profile", path: "/profile", icon: "◎" },
  { name: "Settings", path: "/settings", icon: "⚙" },
];

export default function Sidebar() {
  const pathname = usePathname();
  const router = useRouter();
  const { state, update } = useAppState();

  const handleLogout = () => {
    update({ user: null });
    router.push("/");
  };

  return (
    <aside style={{
      width: "240px",
      minHeight: "100vh",
      background: "#0a0f1a",
      borderRight: "1px solid #1e293b",
      padding: "28px 16px",
      display: "flex",
      flexDirection: "column",
      justifyContent: "space-between",
      flexShrink: 0,
    }}>
      <div>
        <Link href="/dashboard" style={{ textDecoration: "none" }}>
          <h1 style={{ color: "#38bdf8", fontSize: "24px", fontWeight: "800", marginBottom: "40px", letterSpacing: "-0.5px" }}>
            Study<span style={{ color: "white" }}>AI</span>
          </h1>
        </Link>
        <nav style={{ display: "flex", flexDirection: "column", gap: "6px" }}>
          {menuItems.map((item) => {
            const active = pathname === item.path;
            return (
              <Link key={item.name} href={item.path} style={{ textDecoration: "none" }}>
                <div style={{
                  padding: "12px 16px",
                  borderRadius: "12px",
                  color: active ? "#38bdf8" : "#64748b",
                  background: active ? "rgba(56,189,248,0.08)" : "transparent",
                  border: active ? "1px solid rgba(56,189,248,0.2)" : "1px solid transparent",
                  display: "flex",
                  alignItems: "center",
                  gap: "10px",
                  fontSize: "14px",
                  fontWeight: active ? "600" : "400",
                  transition: "all 0.2s",
                  cursor: "pointer",
                }}>
                  <span style={{ fontSize: "16px" }}>{item.icon}</span>
                  {item.name}
                </div>
              </Link>
            );
          })}
        </nav>
      </div>

      <div style={{ background: "#111827", border: "1px solid #1e293b", borderRadius: "14px", padding: "16px" }}>
        <div style={{ display: "flex", alignItems: "center", gap: "10px", marginBottom: "12px" }}>
          <div style={{ width: "36px", height: "36px", borderRadius: "50%", background: "linear-gradient(135deg, #38bdf8, #818cf8)", flexShrink: 0 }} />
          <div>
            <p style={{ color: "white", fontSize: "14px", fontWeight: "600" }}>{state.user?.name || "Guest"}</p>
            <p style={{ color: "#64748b", fontSize: "12px" }}>Student</p>
          </div>
        </div>
        <button onClick={handleLogout} style={{
          width: "100%", padding: "10px", background: "transparent",
          border: "1px solid #1e293b", borderRadius: "10px", color: "#94a3b8",
          fontSize: "13px", cursor: "pointer",
        }}>
          Sign out
        </button>
      </div>
    </aside>
  );
}

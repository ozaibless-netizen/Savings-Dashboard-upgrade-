"use client";
import { usePathname } from "next/navigation";
import { useAppState } from "@/lib/useAppState";

const titles: Record<string, string> = {
  "/dashboard": "Dashboard",
  "/courses": "Courses",
  "/assistant": "AI Assistant",
  "/analytics": "Analytics",
  "/profile": "Profile",
  "/settings": "Settings",
};

export default function TopNavbar() {
  const pathname = usePathname();
  const { state } = useAppState();
  const title = titles[pathname] || "StudyAI";

  return (
    <header style={{
      padding: "18px 32px",
      borderBottom: "1px solid #1e293b",
      background: "rgba(10,15,26,0.8)",
      backdropFilter: "blur(12px)",
      display: "flex",
      justifyContent: "space-between",
      alignItems: "center",
      position: "sticky",
      top: 0,
      zIndex: 100,
    }}>
      <h2 style={{ color: "white", fontSize: "20px", fontWeight: "700" }}>{title}</h2>
      <div style={{ display: "flex", alignItems: "center", gap: "12px" }}>
        <div style={{
          padding: "8px 16px",
          background: "rgba(56,189,248,0.08)",
          border: "1px solid rgba(56,189,248,0.2)",
          borderRadius: "20px",
          color: "#38bdf8",
          fontSize: "13px",
        }}>
          ✦ AI Ready
        </div>
        <div style={{
          width: "38px", height: "38px", borderRadius: "50%",
          background: "linear-gradient(135deg, #38bdf8, #818cf8)",
          display: "flex", alignItems: "center", justifyContent: "center",
          color: "white", fontWeight: "700", fontSize: "15px",
        }}>
          {state.user?.name?.[0]?.toUpperCase() || "?"}
        </div>
      </div>
    </header>
  );
}

import Link from "next/link";

export default function Navbar() {
  return (
    <nav style={{
      display: "flex",
      justifyContent: "space-between",
      alignItems: "center",
      marginBottom: "80px",
    }}>
      <h1 style={{ fontSize: "26px", fontWeight: "800", color: "#38bdf8", letterSpacing: "-0.5px" }}>
        Study<span style={{ color: "white" }}>AI</span>
      </h1>
      <div style={{ display: "flex", gap: "12px" }}>
        <Link href="/login" style={{ textDecoration: "none" }}>
          <button style={{
            padding: "10px 20px", borderRadius: "10px",
            border: "1px solid #334155", background: "transparent",
            color: "white", fontSize: "14px", cursor: "pointer",
          }}>Login</button>
        </Link>
        <Link href="/signup" style={{ textDecoration: "none" }}>
          <button style={{
            padding: "10px 20px", borderRadius: "10px",
            border: "none", background: "#38bdf8",
            color: "#0f172a", fontSize: "14px", fontWeight: "700", cursor: "pointer",
          }}>Sign Up</button>
        </Link>
      </div>
    </nav>
  );
}

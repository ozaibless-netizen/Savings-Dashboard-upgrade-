import Sidebar from "./Sidebar";
import TopNavbar from "./TopNavbar";

type LayoutProps = {
  children: React.ReactNode;
};

export default function PageLayout({
  children,
}: LayoutProps) {
  return (
    <main
      style={{
        minHeight: "100vh",
        display: "flex",
        background:
          "linear-gradient(to bottom right, #0f172a, #111827, #1e293b)",
      }}
    >
      <Sidebar />

      <section
        style={{
          flex: 1,
          display: "flex",
          flexDirection: "column",
        }}
      >
        <TopNavbar />

        <div
          style={{
            padding: "40px",
          }}
        >
          {children}
        </div>
      </section>
    </main>
  );
}